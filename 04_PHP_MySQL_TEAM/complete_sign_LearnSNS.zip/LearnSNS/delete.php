<?php

header("Location: timeline.php");
exit();