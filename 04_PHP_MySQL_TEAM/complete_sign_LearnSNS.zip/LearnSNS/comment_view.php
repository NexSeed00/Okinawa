<div class="collapse" id="collapseComment">
    <div class="col-xs-12" style="margin-top:10px">
        <p style="margin-top: 30px; margin-bottom: 30px">
            <img src="user_profile_img/misae.png" width="40" class="img-circle">
            <span style="border-radius: 100px!important; -webkit-appearance:none;background-color:#eff1f3;padding:10px;margin-top:10px;">
                <a href="profile.php">野原みさえ</a>
                PHP楽しいね！
            </span>
        </p>
        <form method="post" class="form-inline" action="comment.php" role="comment">
            <div class="form-group">
                <img src="user_profile_img/misae.png" width="40" class="img-circle">
            </div>
            <div class="form-group">
                <input type="text" name="write_comment" class="form-control" style="width:400px;border-radius: 100px!important; -webkit-appearance:none;" placeholder="コメントを書く">
            </div>
            <input type="hidden" name="feed_id" value="">
            <div class="form-group">
                <button type="submit" class="btn btn-sm btn-primary">投稿する</button>
            </div>
        </form>
    </div>
</div>